from xmlrpc import client
from flask import Flask
from flask import request
from flask import render_template
app=Flask(__name__)
@app.route('/')
def f1():
    return render_template('index.html')
@app.route('/sendrequest', methods=['POST'])
def f2():
    question= request.form.get('userInput')
    from langchain_huggingface import HuggingFaceEmbeddings
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
    from langchain_community.vectorstores import FAISS
    vector_store = FAISS.load_local("ipc_index", embeddings, allow_dangerous_deserialization=True)
    context = vector_store.similarity_search(question,k=1)
    actual_context = context[0].page_content
    our_prompt = our_prompt = f"""
    Answer the following question in one line.
    If unrelated to IPC, just say: "I am not sure about this question, please consult a lawyer for more information."

    Question: {question}
    Context: {actual_context}

    Return only the answer, no extra explanation.
    """

    from openai import OpenAI
    client = OpenAI(
    base_url="http://127.0.0.1:1234/v1",  # LM Studio API URL
    api_key="lm-studio"  # Dummy key (LM Studio ignores this)
    )
    response = client.chat.completions.create(
    model="local-model",  # LM Studio ignores model name
    messages=[
        {"role": "user", "content": our_prompt}
    ],
    temperature=0.7
    )
    model_answer = response.choices[0].message.content.strip()
    return render_template('sec.html', answer=model_answer)
app.run()
