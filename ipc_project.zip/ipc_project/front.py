# from urllib import response
# from flask import Flask
# from flask import request
# from flask import jsonify
# import requests

# app=Flask(__name__)
# @app.route('/ipc',methods=['POST'])
# def f1():
#     data=request.get_json()
#     question=data.get("ipc_question")
#     from langchain_huggingface import HuggingFaceEmbeddings
#     embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
#     from langchain_community.vectorstores import FAISS
#     vector_store = FAISS.load_local("ipc_index", embeddings, allow_dangerous_deserialization=True)
#     context = vector_store.similarity_search(question,k=1)
#     actual_context = context[0].page_content
#     our_prompt = our_prompt = f"""
#     Answer the following question in one line.
#     If unrelated to IPC, just say: "I am not sure about this question, please consult a lawyer for more information."

#     Question: {question}
#     Context: {actual_context}

#     Return only the answer, no extra explanation.
#     """

#     from openai import OpenAI

# # Connect to LM Studio local server
#     client = OpenAI(
#     base_url="http://127.0.0.1:1234/v1",  # LM Studio API URL
#     api_key="lm-studio"  # Dummy key (LM Studio ignores this)
#     )
#     response = client.chat.completions.create(
#         model="local-model",  # LM Studio ignores model name
#         messages=[
#             {"role": "system", "content": "You are a helpful AI assistant."},
#             {"role": "user", "content": our_prompt}
#         ],
#         temperature=0.7
#     )
#     model_answer = response.choices[0].message.content.strip()
#     print("\n[DEBUG] RAW LM Studio Response Object:\n", response)
#     print("\n[DEBUG] Extracted Model Answer:\n", model_answer)
#     print("\n[DEBUG] Sending This To Postman\n")

#     return jsonify({"response":model_answer})
# app.run()







from langchain_huggingface import HuggingFaceEmbeddings
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
from langchain_community.vectorstores import FAISS
vector_store = FAISS.load_local("ipc_index", embeddings, allow_dangerous_deserialization=True)
question="The IPC section for the bike theft case and name of that?"
context = vector_store.similarity_search(question,k=1)
actual_context = context[0].page_content
our_prompt = our_prompt = f"""
Answer the following question in one line.
If unrelated to IPC, just say: "I am not sure about this question, please consult a lawyer for more information."

Question: {question}
Context: {actual_context}

Return only the answer, no extra explanation.
"""

from openai import OpenAI

# Connect to LM Studio local server
client = OpenAI(
base_url="http://127.0.0.1:1234/v1",  # LM Studio API URL
api_key="lm-studio"  # Dummy key (LM Studio ignores this)
)
response = client.chat.completions.create(
    model="local-model",  # LM Studio ignores model name
    messages=[
        {"role": "user", "content": our_prompt}
    ],
    temperature=0.7
)
model_answer = response.choices[0].message.content.strip()
print(model_answer)