import os
file_path=os.path.join('document','IPC.pdf')
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
import faiss
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS

Loader=PyPDFLoader(file_path)
documents = Loader.load()
print("My document has been loaded.")
print(documents[0].page_content)
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=2000,
    chunk_overlap=500
    )
my_chunk=text_splitter.split_documents(documents)
print(my_chunk[0].page_content) 
print("my chunk has been created.")
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
print("Embeddings have been created.")
index = faiss.IndexFlatL2(len(embeddings.embed_query("hello world")))
vector_store = FAISS(
    embedding_function=embeddings,
    index=index,
    docstore=InMemoryDocstore(),
    index_to_docstore_id={},
)
vector_store.add_documents(documents=my_chunk)
vector_store.save_local("ipc_index")